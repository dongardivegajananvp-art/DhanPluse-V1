DhanPulse Live AI Chart V1

This is a working browser UI preview. It intentionally does not label reference/demo values as live.
Production data architecture: DhanHQ v2 Live Market Feed WebSocket for tick data; Dhan Option Chain for OI, Greeks, IV, volume and bid/ask; Yahoo Finance only as fallback/reference.
Never expose Dhan access tokens in public frontend code; keep them server-side.
